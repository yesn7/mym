#include <stdbool.h>
#include <stdint.h>
#include "driverlib/interrupt.h"
#include "inc/tm4c1294ncpdt.h"

void
complementa(void)
{
	GPIO_PORTN_DATA_R ^= 0x01;
}
void

Timer03IntHandler(void)
{
    //LIMPIA BANDERA
	uint32_t ui32CLRBAN;
	TIMER3_ICR_R= 0X00000001 ; //LIMPIA BANDERA DE TIMER3
    // llama a la funci�n complemento de leds.
    //
    complementa();
}




 main(void) {
	
	 uint32_t ui32Loop;
	 //habilita PORTN
	  SYSCTL_RCGCGPIO_R = SYSCTL_RCGCGPIO_R12;

	     SYSCTL_RCGCTIMER_R |= 0X08; //HABILITA TIMER 3

	     //retardo para que el reloj alcance el PORTN Y TIMER 3
	     ui32Loop = SYSCTL_RCGCGPIO_R;
	     TIMER3_CTL_R=0X00000000; //DESHABILITA TIMER EN LA CONFIGURACION
	     TIMER3_CFG_R= 0X00000000; //CONFIGURAR PARA 32 BITS
	     TIMER3_TAMR_R= 0X00000002; //CONFIGURAR PARA MODO PERIODICO
	     TIMER3_TAILR_R= 0X00FFFFFF; // VALOR DE RECARGA
	     TIMER3_TAPR_R= 0X00; //PARA QUE ES ESTO
	     TIMER3_ICR_R= 0X00000001 ; //LIMPIA BANDERA DE TIMER3
	     TIMER3_IMR_R |= 0X00000001; //ACTIVA INTRRUPCION DE TIMEOUT
	     NVIC_EN1_R= 1<<(35-32); //HABILITA LA INTERRUPCION DE  TIMER3
	     TIMER3_CTL_R |= 0X00000001; //HABILITA TIMER EN LA CONFIGURACION


	     //
	     // habilita el bit 0 como digital
	     // configura como salida
	     //
	     GPIO_PORTN_DIR_R = 0x01;
	     GPIO_PORTN_DEN_R = 0x01;
	     GPIO_PORTN_DATA_R = 0x00;

	     IntMasterEnable();

	     while(1);

}
